# 2301
n-pendulum Mathematica
